# Unplan Parser

한국어 일정 입력에서 날짜·시간·제목 후보를 찾는 순수 TypeScript 패키지다.
React 웹과 향후 Expo SDK 56 앱이 같은 코어를 소비하는 것을 목표로 한다.

**현재: 대화형 일정 파서 P1 (`0.3.0-alpha.1`).** `parseSchedule`을 동기 호출해 날짜·시간·제목,
필드별 상태, UTF-16 원문 위치, diagnostics, 추론 근거를 얻는다. 런타임 의존성은 없다.
Node 22.20.0과 Chromium/Vite 소비를 검증한다. Expo SDK 56/Hermes는 아직 검증하지 않았다.

## 시작하기

Node 22.20.0 (`.nvmrc`), npm 10.9.3을 기준으로 세팅했다.

```sh
nvm use
npm ci
npm test
npm run typecheck
npm run lint
npm run format:check
npm run build
# 전체 검증: npm run check
```

`dist/`에 ESM JavaScript와 `.d.ts`를 만든다. 소스의 내부 import는 `.js` 확장자를 쓴다.
코어는 DOM/Node ambient 타입, UI, 네트워크, 저장소에 의존하지 않는다.

```ts
import { parseSchedule } from '@unplan-tave/parser';

const result = parseSchedule({
  text: '다음 주 월요일에 오후 3시 회의',
  referenceInstant: '2026-11-14T01:00:00Z',
  timeZone: 'Asia/Seoul',
});
// status === 'parsed': date 2026-11-16, time 15:00, title 회의
// 잘못된 context는 status === 'invalid-context'로 반환한다.
```

## 데모와 연결

독립 레포인 [unplan-demo](https://github.com/unplan-tave/unplan-demo)가 같은 상위 폴더에
있다면, parser에서 `npm ci`를 끝낸 뒤 다음을 실행한다.

```sh
cd ../unplan-demo
npm ci
npm run parser:sync
npm run check
npm run dev
```

동기화 스크립트는 parser의 `npm pack`을 통해 빌드하고, demo의 `vendor/`에 tarball을
복사해 공개 패키지로 설치한다. demo의 기존 스냅샷만 실행할 때는 parser 폴더가 필요 없다.
수동 `npm pack` 검증, 다른 경로, Vercel/정식 패키지 전환은
[개발·패키지 연결](docs/development.md)에 설명한다.

## 설계 기준 문서

- [공개 API와 상태 모델](docs/public-api.md)
- [지원 표현과 해석 정책](docs/interpretation-policy.md)
- [대표 입력·기대 결과와 실행 fixture](docs/examples.md)
- [구조·도구 선택과 후속 작업](docs/architecture.md)
- [설치·패키지 검증·배포 전환](docs/development.md)

지원: 오늘·내일·모레·주/요일, 숫자 연월일, 한~열두 시, 오전·오후·시간대 단어,
시·분·반·콜론 시각과 근사 시간, 경과 분/시간 뒤·후, 목적지 정정, 등록된 목적·복합 동작,
여러 행동·명시 날짜 선택·순서 관계, NFC/NFD의 원문 위치 보존.
날짜·시간은 독립적이며 날짜만으로 자정·종일, 시간만으로 오늘을 채우지 않는다.
밤 12시·1시의 날짜 경계와 이중 부정은 확인한다. 반복·기간·마감, 등록 문법 밖의 일반 의도
해석, 저장 instant/DST gap·fold 선택은 지원 밖이다.
npm test는 문서 예시 39개, 내부 입력 80개, 대화 설계 64개와 P1 정책·경계·성능 회귀를 실행한다.
Expo SDK 56/Hermes와 실제 한국어 자료 기반 검증은 후속 작업이다.
패키지 이름 `@unplan-tave/parser`와 라이선스는 임시 결정이다. npm scope 소유권과 공개
라이선스 승인 전에는 게시하지 않는다. 이번 MVP 작업에서는 게시·배포·커밋·푸시·PR을 하지 않는다.

## 대화형 일정 제안 (0.3 P1)

`parseSchedule`의 `suggestions`에서 행동별 날짜·오전·오후 대안, 근사 시간과 행동 제목의
변환 근거를 제공한다. 소비자는 한 후보를 선택해 초안을 열고 실제 저장은 별도로 결정한다.
부정·충돌·미지원 구문은 확인/보류하고, 알 수 없는 제목은 원문 잔여를 보존해 편집을 요청한다.
계약은 [공개 API](docs/public-api.md), 지원 범위는 [정책](docs/interpretation-policy.md)을 따른다.

여러 행동은 독립 그룹으로 반환한다. 같은 입력에서 명시적으로 연결한 절에만 날짜를
이어 주며 시간을 복사하지 않는다. 순서는 temporalRelation으로 보존한다.
자세한 범위와 검증은 [P1 구현 기록](docs/p1-implementation.md)을 따른다.
