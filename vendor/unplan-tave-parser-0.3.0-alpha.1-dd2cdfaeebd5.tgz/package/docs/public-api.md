# 공개 API (MVP)

API 버전 `0.3.0-conversation.1`, 정책 버전 `ko-schedule-v0.3-p1.1`.
이 문서는 구현된 MVP의 계약이다. 공개 타입은 `src/types.ts`, 단일 진입점은 `src/index.ts`다.

## 현재 사용 가능한 진입점

```ts
import {
  parseSchedule,
  PARSER_INFO,
  INITIAL_POLICIES,
} from '@unplan-tave/parser';
import type {
  ParseInput,
  ParseResult,
  InvalidContextResult,
  ScheduleParser,
} from '@unplan-tave/parser';
```

ESM 루트 하나를 제공한다. `dist/index.js`, `dist/index.d.ts`를 각각 JavaScript·타입
진입점으로 사용한다. 내부 파일 deep import와 CommonJS `require`는 지원 대상으로
선언하지 않는다. Vite 소비는 검증하지만 Expo SDK 56/Hermes 소비는 후속 검증이다.

`PARSER_INFO.implementation`은 `available`이다. `parseSchedule`은 `ScheduleParser` 타입을
만족하는 실제 동기 함수다. `INITIAL_POLICIES`는 구현에 적용한 MVP 기본 정책이다.

## 호출 계약

```ts
type ScheduleParser = (input: ParseInput) => ParseResult | InvalidContextResult;

// parseSchedule(input)으로 전체 문자열을 매번 분석한다.
const input: ParseInput = {
  text: '다음 주 월요일에 오후 3시 회의',
  referenceInstant: '2026-11-14T01:00:00Z',
  timeZone: 'Asia/Seoul',
};
```

- `text`: 수정·정규화 전 원문. 빈 문자열도 정상 입력이다.
- `referenceInstant`: `Z` 또는 명시적 offset을 포함한 ISO 8601 시각. 예:
  `2026-11-14T10:00:00+09:00`. offset 없는 문자열은 거부한다.
- `timeZone`: IANA 시간대 ID. 기준 시각을 이 시간대의 달력 날짜로 변환한다.
  시스템 시각·시간대 기본값, timezone 없는 Date 파싱을 사용하지 않는다.
- 현지 달력 날짜는 서기 0001~9999년 범위다. offset/시간대 변환으로 이 범위를
  벗어나는 context는 `invalid-reference-instant`로 거부한다. 유효한 context에서
  상대 날짜·주간 범위 계산 결과가 벗어나면 날짜 필드는 `invalid-date`이며
  독립적인 시간·제목은 유지한다. 범위의 끝 제외 날짜도 같은 제약을 따른다.
- 정책 override는 MVP 입력에 포함하지 않는다. `INITIAL_POLICIES`를 따르며,
  향후 옵션 도입 시 문서와 타입을 같이 변경한다.
- 유효한 context는 `status: 'parsed'`로 반환한다. 자연어가 없거나 모호·미완성·잘못된
  경우에도 정상 분석 결과이며, 필드의 상태와 diagnostics로 설명한다.
- 잘못된 기준 시각 또는 지원하지 않는 시간대는 `status: 'invalid-context'`와
  `errors`를 반환한다. 이 경우 계산된 필드를 만들지 않는다. 잘못된 사용자 입력으로
  예외를 던지는 대신 이 union을 사용한다. 현재 실행 환경의 Intl IANA 지원을 검사하며, 실패하면 오류 union을 반환한다.

## 필드별 상태

날짜 `Field<DateValue>`, 시간 `Field<TimeValue>`, 제목 `Field<string>`을 독립적으로 반환한다.

| state        | 의미                                               | 필수 정보                                      |
| ------------ | -------------------------------------------------- | ---------------------------------------------- |
| `none`       | 해당 정보 없음                                     | 값/후보 없음                                   |
| `incomplete` | 시작했으나 완성되지 않은 표현                      | `sources`, `expected`(기대하는 다음 토큰 설명) |
| `resolved`   | 하나의 값으로 해석됨                               | `candidate`                                    |
| `ambiguous`  | 사용자의 선택이나 추가 입력이 필요함               | 최소 두 `candidates`, `sources`, `reason`      |
| `invalid`    | 지원 문법과 일치하지만 값이 유효하지 않거나 충돌함 | `sources`, `code`, `message`                   |

`다음 주 월요일에 오후`는 날짜 `resolved`, 시간 `incomplete`, 제목 `none`이다.
하나의 전역 `incomplete`로 나머지 날짜를 없애지 않는다. 제목은 초기 정책에서 주로
`none` 또는 `resolved`를 사용한다. 날짜 범위도 값 자체는 `resolved`일 수 있으므로,
소비자는 `state`뿐 아니라 `value.kind`를 확인해야 한다.

## 값·위치·근거

`DateValue`:

- `{ kind: 'date', date: '2026-11-16' }`: 해당 시간대의 달력 날짜.
- `{ kind: 'range', startDate: '2026-11-16', endDateExclusive: '2026-11-23', granularity: 'week' }`:
  달력의 주간 범위. 종료 날짜는 제외한다. 일정 시작·종료 시간이 아니다.

날짜만으로 ISO timestamp, `00:00`, `allDay: true`를 만들지 않는다. 계약에 일정 저장용
timestamp나 allDay 필드를 넣지 않는다. 날짜와 시간이 둘 다 있어도 instant로 조합하는
책임은 이후 일정 도메인 계층에 있다. DST gap/fold, 저장·종일 여부도 그 계층에서 결정한다.

`TimeValue`: `hour` 0–23, `minute` 0–59, `precision: 'hour' | 'minute'`.
`오후 3시`는 시 정밀도이며 생략된 분 0은 추론으로 기록한다. `반`, `분`, `HH:mm`은 분
정밀도다. 시간만 있다고 날짜를 오늘로 채우거나 과거 시간을 내일로 넘기지 않는다.

`Candidate<T>`는 `value`, `sources`, `derivations`를 갖는다. `SourceSpan`은
`{ start, end, text }`이며 **UTF-16 code unit, 0부터, end 제외**다. 항상
`input.text.slice(start, end) === text`. NFC/NFD는 인식용 NFC 문자열과 원문 UTF-16 구간 매핑으로 처리한다. 반환 위치와
source.text는 항상 수정 전 원문 기준이며, 정규화된 제목에는 unicode-normalization 근거를 남긴다. 이모지 뒤 위치도 JavaScript 문자열 인덱스를 따른다.
후보가 여러 island에서 조합되면 서로 떨어진 범위를 `sources`로 보존한다.

`Derivation.path`는 후보 값 기준 JSON pointer다. 문자열 자체의 경로는 빈 문자열 `''`.

- `kind: 'explicit'`: 사용자 원문에서 직접 온 값과 `sources`.
- `kind: 'inferred'`: `policy`, `sources`를 포함해 규칙으로 결정한 값.
- `오후 3시`: `/hour`는 `meridiem-to-24-hour`, `/minute`은
  `default-minute-zero` 추론. 원문에 명시된 숫자·오후는 source로 보존한다.
- `내일`: `/date`는 `relative-date` 추론. 표현은 명시되었어도 절대 날짜는 기준 시각과
  정책으로 계산된 값이므로 explicit이라고 표시하지 않는다.
- `15:30`: `/hour`, `/minute` 모두 explicit. 시/분 범위를 개별로 지정할 수 있다.
- 제목의 순수 잔여 텍스트는 explicit, 공백 결합을 거치면 `title-whitespace` 추론.

`LocalDate`, `ReferenceInstant`, IANA ID는 현재 단순 string alias다. TS 타입만으로 형식이나
값 범위를 보장한다고 주장하지 않는다. 엔진이 ISO 날짜·시각의 범위와 offset 및 Intl 시간대 가용성을 검증한다.

`expressions`는 날짜/시간의 complete·incomplete·ambiguous·invalid island와 원문 범위를
반환한다. `diagnostics`는 원문 위치와 안정적인 code를 담는다. UI는 번역 가능한 code를
사용하고 message 문구에 의존한 조건 분기를 하지 않는다. 지원하지 않는 반복·기간처럼
위험한 조합은 `unsupported-expression` warning을 통해 알린다.

## 대화형 제안 계약 (0.3 P1)

`ParseResult.suggestions: ConversationSuggestions`는 등록된 연결 문법의 각 행동과 해당 날짜·시간을
묶는다. 기존 date/time/title 필드는 독립 인식·진단용으로 유지한다. **기존 title은 시간
island를 제외한 잔여 텍스트이며 정리된 행동 제목이 아니다.** 버튼과 초안은 반드시
suggestions를 사용한다. `invalid-context`에는 제안이 없다.

```ts
const result = parseSchedule({
  text: '음 내일 3시쯤 카페 갈 거야',
  referenceInstant: '2026-11-15T01:00:00Z',
  timeZone: 'Asia/Seoul',
});
// parsed: suggestions.decision === 'offer', reason === 'missing-meridiem'
// groups[0].title: value '카페 가기', form 'normalized'
// options: 2026-11-16 / 03:00, 2026-11-16 / 15:00 (각 time.qualification='approximate')
```

| decision     | 소비자 동작                                                                  |
| ------------ | ---------------------------------------------------------------------------- |
| offer        | groups의 한 후보를 선택하여 편집 초안을 연다. 자동 저장하지 않는다.          |
| review-title | title.form=verbatim, 원문 잔여를 보존하고 제목 편집을 요청한다. 후보는 없다. |
| clarify      | 원문·독립 필드를 유지하고 확인/지원 범위를 안내한다. 후보는 없다.            |
| no-offer     | 빈 입력·값 오류·부정·기존 일정 조작·조회 등. 긍정 추가 후보를 만들지 않는다. |

`reason`은 `SuggestionReason`의 안정적인 code이며 설명문 비교로 분기하지 않는다.
`groups`는 최대 8개, 그룹당 options는 최대 4개, 전체 options 합계는 최대 16개다.
초과하면 일부를 버리지 않고 candidate-limit으로 확인을 요청한다. group의 frameId/options.id는
**한 parse 결과 안에서만 유효**하다. message ID/revision은 소비자가 관리한다.
`relation: single | alternatives`, `selection: one-of`이며 서로 다른 행동·날짜·시각을
전체 교차 조합하지 않는다. 한 행동에서 명시한 날짜 선택 두 개와 AM/PM 두 개만
최대 네 대안으로 조합한다. 각 그룹의 선택은 독립적이며 자동 저장하지 않는다. 명시 시각 충돌은 `conflicting-explicit-clocks`, 단독
1~12시의 두 대안은 `missing-meridiem`으로 구분한다. 같은 시각 반복은 병합한다.

`SuggestedTitle`은 value(string|null), form(normalized/literal/verbatim/missing),
sources, derivations, ruleIds, edits를 갖는다. edits는 소비·변환한 원문 sources와
replacement, ruleId를 남긴다. N01은 날짜·시간 제거, S04는 문두 담화어, N02는
등록 요청, N03~N05는 검증된 동사 변환이다. normalized는
`action-title-normalization` inferred다. literal은 등록된 짧은 행동 제목이며 단순히
날짜·시간만 제거했다고 literal/normalized가 되지 않는다. 빈 제목은 null이고 초안에서 입력한다.

`ScheduleOption`은 id와 `Candidate<{date: LocalDate; time: TimeValue|null}>`이다.
각 option에 날짜·시간 sources/derivations를 보존한다. title은 같은 group에만 결합한다.
`timeQualification: none | unqualified | approximate`와 unfinishedTime(string|null)을
초안에 전달한다. 시간 없음/미완성은 null이며 자정/종일이 아니다. `TimeValue`의 선택적
`qualification: approximate`는 근사 기준값이다. 생략 시 근사 수식어가 없다.
`쯤`, `정도`, 시간 앞의 `약`을 해당 시간 span에 포함하며 `/qualification`에
`approximate-time` 추론을 남긴다. 정확한 시작·±범위·timestamp를 만들지 않는다.

전송 시 원문과 context를 함께 고정한다. 새 메시지에 옛 날짜를 상속하지 않는다.
소비자가 원문 편집 기능을 추가하면 revision을 올리고 이전 후보를 무효화해야 한다.
한 후보를 클릭한 초안만 열고, 닫으면 재선택할 수 있다. 서버/저장 계약은 없다.

## P1 값·결합·순서 계약

- 한~열두 시를 지원한다. 콜론 시각과 분 숫자는 ASCII 숫자이며 한글 수사 분은
  지원하지 않는다. 수사 시간은 korean-numeral-hour inferred 근거를 갖는다.
- 아침/낮/저녁/밤/새벽 + 명시 시각은 정책의 조합표로 검증한다. 단어만으로 시각을
  채우지 않는다. 밤 12시·1시는 midnight-date-clarification이며 날짜를 자동 이월하지 않는다.
- 숫자 날짜는 YYYY-MM-DD, [숫자 년] 숫자 월 숫자 일이다. 연도 생략은 오늘을 포함한
  다음 유효한 연례 날짜(2월 29일은 다음 윤년)이며 omitted-year-next-occurrence 근거를 남긴다.
  명시 연도의 과거 날짜는 유지한다. 날짜 오류/미완성 때문에 독립 시간은 사라지지 않는다.
- 정수 또는 등록 수사 + 분/시간 + 뒤/후는 기준 instant에 경과 분을 더한 다음 IANA 시간대로 변환한다.
  날짜와 시간에 relative-instant 근거를 남기며 초는 결과의 분 정밀도로 버린다.
  이 계산도 저장 timestamp를 반환하지 않는다. 기간만 있는 숫자+분/시간은 여전히 보류다.
- 한 문장 안에서 등록된 연결 어미(가고/먹고/보고/읽고/듣고/만나고/걷고/쓰고/하고/
  들르고), 그리고, 쉼표·세미콜론으로 행동을 분리한다. 각 절은 독립적으로 검증한다.
  명시 날짜가 있는 앞 절의 날짜가 제목보다 앞에 있을 때만 다음 연결 절에 날짜를
  이어 주며 same-utterance-date 근거를 남긴다. 시간과 날짜 선택 대안은 상속하지 않는다.
  다른 메시지나 연결 없는 나열에 적용하지 않는다.
- 이나/또는/혹은으로 직접 연결된 날짜 두 개만 한 행동의 선택으로 승인한다.
  단순 날짜 나열은 확인 대상이다.
- 단일 목적지 명사구의 단어 하나 + 말고 + 대체 단어 + 등록 동사만 정정한다.
  날짜·시각 정정과 복잡한 명사구의 정정 범위는 확인한다. B09 edit에 근거를 남긴다.
- 등록된 목적절과 사 오다/해 놓다/들고 가다/들고 오다를 제목에 보존한다.
  임의 술어 복원이나 목적 삭제를 하지 않는다.
- 명사형+전에, 연결형+나서, 행동 명사+한 뒤는 두 행동으로 나눈다. 뒤에 기술한 행동의
  temporalRelation은 {kind: before|after, targetFrameId, sources}다. 예:
  카페 가기 전에 은행 들르기 → 은행 그룹이 카페 그룹보다 before.
  날짜는 같은 발화의 명시 날짜 범위를 따르고, 순서만으로 시간·기간은 만들지 않는다.
  소비자는 이 관계를 후보와 초안에 표시해야 한다.
- 부정·조건·희망·질문·타인 계획 보호는 전체 발화에 먼저 적용한다. 한 절이라도
  확인/보류 대상이면 전체 그룹을 보류한다. 이중 부정도 계획 확정으로 바꾸지 않는다.

## 변경 원칙

`0.3.0-alpha.1`은 위 P1 등록 문법, 원문 정규화 매핑, 여러 행동 그룹과 순서 관계를 추가했다.
P0 독립 필드와 런타임 export 세 개는 유지한다. 일부 과거 미지원 입력은 새 값으로 해석된다.

`0.2.0-alpha.1`은 P0 대화 제안 계약을 추가했다. 근사 시간 인식으로 기존 잔여 title에서
시간 수식어가 제외될 수 있다. 기존 date/time 상태는 보존하고 제안 여부를 분리했다.
시간이 ambiguous라는 이유만으로 모든 제안을 막던 정책을 변경했다. 당시 P1은 안전한 clarify만 검사했다. 현재 P1 지원 범위는 위 계약을 따른다. 런타임 export 세 개는 유지한다.

`0.1.0-alpha.2`에서는 연도 경계의 잘못된 날짜 확정을 수정하고 양의 4자리
달력 라벨 범위를 명시했다. API/정책 버전의 `.2`는 이 경계 검증을 반영한다.
지원하는 한국어 문법과 일반 날짜·시간 해석 기본값, 공개 타입·런타임 export는 유지한다.

계약·정책의 의미가 바뀌면 타입, 두 버전 상수, 정책/예시 문서, 소비자 tarball을 함께
갱신한다. alpha 버전이라도 소비자 호환성을 검토하며, 정식 게시 시 immutable 버전을 쓴다.

## 초안에서 MVP로 전환한 기록

공개 Field/값/결과 union의 의미는 유지했다. 실제 함수 export를 추가하고 API 버전을
`0.1.0-draft.1`에서 `0.1.0-mvp.1`로 올렸다. 초기 정책 버전은 가정을 기본값으로 채택한
`ko-schedule-v0-mvp.1`이었다. 이후 `.2`의 연도 경계 수정은 위 변경 기록을 따른다.

같은 시·분의 반복은 정밀도가 달라도 한 값으로 병합하며, 분 정밀도를 보존한다.
명확한 범위 오류는 같은 표현이 아직 입력 중이어도 invalid가 우선한다.
지원하지 않는 초 표기(`23:30:45`)를 작은 시간으로 자르지 않는다.
기준 ISO 문자열은 4자리 양의 연도, T, 시·분, 선택적 초·소수초, Z 또는 ±HH:mm을 받으며
24시·존재하지 않는 날짜·offset 없는 시각을 거부한다. named zone/alias는 호스트 Intl이
지원해야 하며 숫자 offset을 IANA ID 대신 주는 것은 거부한다.
