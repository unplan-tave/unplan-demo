# 구조와 초기 선택 기록

## 책임 분리

향후 코어 내부 흐름은 다음 순서다. 현재는 아래 모듈을 구현하지 않았으며,
파일 구조를 미리 채우기 위한 빈 클래스나 성공 stub도 만들지 않았다.

1. **scan**: 원문 정규식 스캔. 날짜/시간/조사/미완성 접두사 토큰과 UTF-16 위치 생성.
2. **recognize**: 작은 수동 함수로 주+요일, 오전/오후+시/분 같은 island 조합.
   이 단계는 달력 날짜나 현재 시각에 접근하지 않고 상징적 규칙을 만든다.
3. **resolve**: 주입된 instant와 IANA zone을 사용해 달력 날짜·시간·모호 후보를 계산.
   타임존 어댑터는 별도 내부 경계로 두고 브라우저/Expo 실제 가용성을 확인한다.
4. **assemble**: 필드별 상태, 근거, 진단 및 원문 범위를 조립. 소비된 island/조사를
   제외한 제목을 추출한다. 전체 입력을 한 번의 순수 호출로 처리한다.

UI, hook, 저장, API 호출, 특정 날짜 제안 버튼, 초안 편집은 consumer의 책임이다.
날짜/시간의 local 값으로부터 실제 저장 instant를 만드는 책임도 일정 도메인에 있다.
일반 대화 의도를 이해한다고 가정하지 않는다.

## 도구 선택 이유

| 선택                                                           | 이유와 한계                                                                     |
| -------------------------------------------------------------- | ------------------------------------------------------------------------------- |
| 독립 Git + npm/독립 lockfile                                   | 레포별 배포·버전 관리. 모노레포나 workspace로 묶지 않음                         |
| ESM, TS NodeNext, ES2022                                       | JS+선언 파일을 단순 tsc로 생성. Vite와 미래 Metro 소비를 목표로 함; CJS 미지원  |
| 코어 lib ES2022, types []                                      | DOM/Node ambient 전역에 실수로 의존하는 것을 타입 검사에서 차단                 |
| strict + exactOptionalPropertyTypes + noUncheckedIndexedAccess | 필드 없음과 undefined 혼동, offset 인덱스 오류 줄임                             |
| 타입·상수만 공개                                               | 현재 엔진이 없다는 사실을 런타임과 문서에 일치시킴                              |
| Node 22.20.0 / npm 10.9.3 도구 기준                            | 현재 설치 환경에 맞춘 재현성. 코어 런타임이 Node를 요구한다는 뜻은 아님         |
| TypeScript 6.0.3, ESLint 10, typescript-eslint 8               | 현재 TS 최신 major보다 lint peer 범위(<6.1)에 맞추는 호환성 선택                |
| Prettier 별도 check + eslint-config-prettier                   | lint 규칙과 포맷 중복·충돌 방지                                                 |
| runtime dependency 없음                                        | NLP나 거대한 날짜 도구를 미리 도입하지 않음. IANA 달력 계산 도구는 구현 시 평가 |
| npm pack tarball을 demo/vendor에 포함                          | 실제 배포 산출물 검증 + 독립 설치 + 형제 폴더 없는 Vercel 빌드                  |
| tarball 파일명에 내용 hash                                     | 같은 alpha 버전 재빌드 때 npm 캐시/lockfile의 오래된 integrity 충돌 방지        |
| Vite/React + 작은 CSS tokens                                   | 정적 배포, 빠른 로컬 화면, UI 의존성 최소화                                     |
| package license UNLICENSED                                     | 공개 라이선스를 임의로 부여하지 않음. 이름/scope/라이선스는 게시 전에 결정      |

공식 설정 참고:
[Vite 시작하기](https://vite.dev/guide/),
[npm pack](https://docs.npmjs.com/cli/v11/commands/npm-pack/),
[TypeScript lib](https://www.typescriptlang.org/tsconfig/lib.html).
도구의 정확한 버전은 각 package.json과 lockfile을 기준으로 한다.

## 다음 구현 순서

1. 이 정책 가정 합의 및 계약 fixture 작성. 미실행 예시를 실제 테스트로 전환한다.
2. scan/recognize와 원문 offset·띄어쓰기·조사 경계 구현.
3. IANA 시간대 달력 계산 어댑터와 상대 날짜/주/요일 계산. 월말·연말·윤년·zone 경계 검증.
4. 시간·필드별 상태·다중 표현 충돌·제목·unsupported guard 구현.
5. 실제 `parseSchedule` export와 메타데이터 상태 갱신. JS 및 타입 소비자 검증.
6. demo 입력 변경 때 동기 전체 분석을 연결하고 partial 상태와 초안 액션 구현.
7. Expo SDK 56/Hermes에서 동일 tarball의 import, 정규식 및 IANA 가용성 검증.

반복·기간·다중 일정·대화 의도는 별도 확장 설계로 남긴다. 초기 앱/데모의 코드에 숨겨
넣지 않는다. CI workflow, npm 게시, Vercel 배포는 이번 세팅 범위 밖이다.
