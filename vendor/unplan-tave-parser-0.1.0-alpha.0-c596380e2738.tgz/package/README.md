# Unplan Parser

한국어 일정 입력에서 날짜·시간·제목 후보를 찾을 순수 TypeScript 패키지다.
React 웹과 향후 Expo SDK 56 앱이 같은 코어를 소비하는 것을 목표로 한다.

**현재: 초기 환경과 공개 계약 초안만 준비되었다. 자연어 파싱 함수는 구현·export하지
않는다.** 패키지에는 공개 타입, 실제 미구현 상태를 나타내는 `PARSER_INFO`, 정책 초안인
`INITIAL_POLICIES`가 있다. 날짜 계산 및 Expo 런타임 호환성은 아직 검증하지 않았다.

## 시작하기

Node 22.20.0 (`.nvmrc`), npm 10.9.3을 기준으로 세팅했다.

```sh
nvm use
npm ci
npm run typecheck
npm run lint
npm run format:check
npm run build
# 전체 검증: npm run check
```

`dist/`에 ESM JavaScript와 `.d.ts`를 만든다. 소스의 내부 import는 `.js` 확장자를 쓴다.
코어는 DOM/Node ambient 타입, UI, 네트워크, 저장소에 의존하지 않는다.

```ts
import { PARSER_INFO } from '@unplan-tave/parser';
import type { ParseInput, ScheduleParser } from '@unplan-tave/parser';
// ScheduleParser는 미래 함수의 타입이다. parseSchedule 런타임 export는 없다.
```

## 데모와 연결

독립 레포인 [unplan-demo](https://github.com/unplan-tave/unplan-demo)가 같은 상위 폴더에
있다면, parser에서 `npm ci`를 끝낸 뒤 다음을 실행한다.

```sh
cd ../unplan-demo
npm ci
npm run parser:sync
npm run check
npm run dev
```

동기화 스크립트는 parser의 `npm pack`을 통해 빌드하고, demo의 `vendor/`에 tarball을
복사해 공개 패키지로 설치한다. demo의 기존 스냅샷만 실행할 때는 parser 폴더가 필요 없다.
수동 `npm pack` 검증, 다른 경로, Vercel/정식 패키지 전환은
[개발·패키지 연결](docs/development.md)에 설명한다.

## 설계 기준 문서

- [공개 API와 상태 모델](docs/public-api.md)
- [지원 표현과 해석 정책](docs/interpretation-policy.md)
- [대표 입력·기대 결과: 미실행 설계 예시](docs/examples.md)
- [구조·도구 선택과 후속 작업](docs/architecture.md)
- [설치·패키지 검증·배포 전환](docs/development.md)

다음 단계는 토큰 식별, 표현 조합, 시간대 기반 달력 계산, 원문 위치 및 제목 추출,
경계 테스트, 데모의 실제 함수 연결이다. 반복·기간·다중 일정·일반 대화 의도는 이후 확장이다.
패키지 이름 `@unplan-tave/parser`와 라이선스는 임시 결정이다. npm scope 소유권과 공개
라이선스 승인 전에는 게시하지 않는다. 이번 세팅에서는 게시·배포·커밋·푸시·PR을 하지 않는다.
