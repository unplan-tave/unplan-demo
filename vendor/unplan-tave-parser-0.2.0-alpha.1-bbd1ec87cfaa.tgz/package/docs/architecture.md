# 구조와 초기 선택 기록

## 책임 분리

`parseSchedule`은 아래 모듈을 순서대로 호출한다. 빈 stub이나 하드코딩 결과는 없다.

1. **scan**: 원문 정규식 스캔. 날짜/시간/조사/미완성 접두사 토큰과 UTF-16 위치 생성.
2. **recognize**: 작은 수동 함수로 주+요일, 오전/오후+시/분 같은 island 조합.
   이 단계는 달력 날짜나 현재 시각에 접근하지 않고 상징적 규칙을 만든다.
3. **resolve**: 주입된 instant와 IANA zone을 사용해 달력 날짜·시간·모호 후보를 계산.
   타임존 어댑터는 별도 내부 경계로 두고 브라우저/Expo 실제 가용성을 확인한다.
4. **assemble**: 필드별 상태, 근거, 진단 및 원문 범위를 조립. 소비된 island/조사를
   제외한 잔여 title을 추출한다.
5. **conversation**: 단일 절 결합·의도 보호 후 검증된 행동 제목과 최대 두 시간 대안을
   suggestions로 만든다. 미지원/충돌은 보류하며 제목 변환 근거를 남긴다.
   전체 입력을 한 번의 순수 호출로 처리한다.

UI, hook, 저장, API 호출, 특정 날짜 제안 버튼, 초안 편집은 consumer의 책임이다.
날짜/시간의 local 값으로부터 실제 저장 instant를 만드는 책임도 일정 도메인에 있다.
일반 대화 의도를 이해한다고 가정하지 않는다.

## 도구 선택 이유

| 선택                                                           | 이유와 한계                                                                                              |
| -------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------- |
| 독립 Git + npm/독립 lockfile                                   | 레포별 배포·버전 관리. 모노레포나 workspace로 묶지 않음                                                  |
| ESM, TS NodeNext, ES2022                                       | JS+선언 파일을 단순 tsc로 생성. Vite와 미래 Metro 소비를 목표로 함; CJS 미지원                           |
| 코어 lib ES2022, types []                                      | DOM/Node ambient 전역에 실수로 의존하는 것을 타입 검사에서 차단                                          |
| strict + exactOptionalPropertyTypes + noUncheckedIndexedAccess | 필드 없음과 undefined 혼동, offset 인덱스 오류 줄임                                                      |
| 실제 함수·타입·상수 공개                                       | parseSchedule의 동작과 타입 계약을 함께 검증                                                             |
| Node 22.20.0 / npm 10.9.3 도구 기준                            | 현재 설치 환경에 맞춘 재현성. 코어 런타임이 Node를 요구한다는 뜻은 아님                                  |
| TypeScript 6.0.3, ESLint 10, typescript-eslint 8               | 현재 TS 최신 major보다 lint peer 범위(<6.1)에 맞추는 호환성 선택                                         |
| Prettier 별도 check + eslint-config-prettier                   | lint 규칙과 포맷 중복·충돌 방지                                                                          |
| runtime dependency 없음                                        | NLP나 거대한 날짜 도구를 미리 도입하지 않음. Intl로 현지 날짜를 추출하고 UTC 컨테이너로 달력 날짜만 계산 |
| npm pack tarball을 demo/vendor에 포함                          | 실제 배포 산출물 검증 + 독립 설치 + 형제 폴더 없는 Vercel 빌드                                           |
| tarball 파일명에 내용 hash                                     | 같은 alpha 버전 재빌드 때 npm 캐시/lockfile의 오래된 integrity 충돌 방지                                 |
| Vite/React + 작은 CSS tokens                                   | 정적 배포, 빠른 로컬 화면, UI 의존성 최소화                                                              |
| package license UNLICENSED                                     | 공개 라이선스를 임의로 부여하지 않음. 이름/scope/라이선스는 게시 전에 결정                               |

공식 설정 참고:
[Vite 시작하기](https://vite.dev/guide/),
[npm pack](https://docs.npmjs.com/cli/v11/commands/npm-pack/),
[TypeScript lib](https://www.typescriptlang.org/tsconfig/lib.html).
도구의 정확한 버전은 각 package.json과 lockfile을 기준으로 한다.

## 구현과 검증 경계

`scan.ts`는 토큰·guard 위치, `recognize.ts`는 상징적 island를 만든다.
`calendar.ts`가 ISO/Intl context 검증과 달력 날짜 계산을 담당하며 `resolve.ts`는
후보와 근거를 계산한다. `assemble.ts`가 충돌·우선순위·제목을 조립하고 `parse.ts`가
전체 흐름을 연결한다. 내부 모듈은 package exports로 노출하지 않는다.

달력 계산의 UTC Date는 달력 라벨의 연산 컨테이너다. 현지 자정 instant를 만들거나
하루를 현지 instant의 24시간으로 가정하지 않으므로 DST 변경에 따라 날짜가 밀리지 않는다.
오프셋이 있는 기준 instant만 Date로 파싱하며 호스트 시간대·시계는 사용하지 않는다.

Node의 기본 테스트 러너가 배포 JS를 테스트하고, 데모는 tarball 루트 export만 소비한다.
데모의 화면 조립, 결과 표시, 액션 정책, 초안 편집을 분리했다. 클릭으로 열린 초안은
원문이 바뀌어도 유지되는 독립 메모리 상태이며 저장·서버 통신은 없다.

다음 작업은 Expo SDK 56/Hermes에서 동일 tarball의 import, 정규식, Intl/IANA 가용성
검증이다. 반복·기간·다중 일정과 등록 문법 밖의 대화 해석은 별도 설계로 남긴다.
CI workflow와 npm 게시는 범위 밖이다. 데모의 Vercel 배포 검증은 데모 릴리스 기록에 남긴다.
