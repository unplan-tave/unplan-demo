# 개발과 패키지 연결

## 독립 레포 설치

두 폴더는 별도 `.git`과 `package-lock.json`을 유지한다. 모노레포 npm workspace로
전환하지 않는다. 기본 폴더명은 `unplan-parser`, `unplan-demo`다.

각 폴더에서 `.nvmrc`의 Node 22.20.0 (`nvm use`), npm 10.9.3으로 아래를 실행한다.

```sh
npm ci
npm test
npm run check
```

`check`: strict 타입 검사, ESLint(경고도 실패), Prettier 확인, 빌드.
개발 의존성 버전은 정확한 값으로 저장하며 lockfile을 관리한다. npm 외 패키지 매니저의
lockfile을 추가하지 않는다. 도구 버전 업그레이드는 peer dependency를 함께 검토한다.

## 권장 로컬 갱신

parser에 `npm ci`가 완료되어 있고 두 레포가 형제 폴더라면 demo에서:

```sh
npm run parser:sync
npm run check
npm run dev
```

다른 parser 위치: `npm run parser:sync -- /absolute/path/to/unplan-parser`.
개발 스크립트 `scripts/sync-parser.mjs`는 Node 도구이며 코어에 포함되지 않는다.

1. parser의 package name 확인 후 임시 폴더로 `npm pack` 실행. `prepack`이 빌드한다.
2. tarball 내용의 SHA-256 일부를 파일명에 넣어 demo의 `vendor/`로 복사한다.
3. `npm install --save-exact --ignore-scripts ./vendor/<archive>.tgz`로 설치해 demo의
   package.json과 lockfile을 갱신한다. 설치할 파일은 이미 prepack으로 빌드되어 있다.
4. 설치 성공 후 이전 parser 스냅샷을 제거한다. 입력 중 실패해도 기존 파일은 보존된다.

이후 `npm ci`만으로 동일 tarball을 설치할 수 있다. 개발 변경은 자동 hot-link되지 않으며
parser 수정 후 다시 sync해야 한다. 같은 내용으로 sync를 반복해도 같은 hash를 사용한다.

## 수동 npm pack 검증

parser 루트에서:

```sh
npm run check
mkdir -p artifacts
npm pack --dry-run --json
npm pack --pack-destination artifacts
tar -tzf artifacts/unplan-tave-parser-0.2.0-alpha.1.tgz
```

출력은 `dist/`의 JS·선언 파일(내부 모듈 포함), `docs/`,
README.md, package.json만 허용한다. src, node_modules, AGENTS, 설정, lockfile, artifacts,
테스트는 포함하지 않는다. `types.js`는 타입 전용 모듈의 빈 ESM 산출물이며 정상이다.

수동 소비자 검증은 demo에서 아래처럼 수행할 수 있다. 현재 스냅샷을 의도적으로 교체하므로
일반 개발에서는 hash를 자동 관리하는 sync 명령을 우선 사용한다.

```sh
mkdir -p vendor
cp ../unplan-parser/artifacts/unplan-tave-parser-0.2.0-alpha.1.tgz vendor/
npm install --save-exact --ignore-scripts ./vendor/unplan-tave-parser-0.2.0-alpha.1.tgz
npm run check
node --input-type=module -e 'import("@unplan-tave/parser").then(m => console.log(Object.keys(m), m.PARSER_INFO))'
```

동일 이름 파일을 덮어쓰며 수동 설치하면 lockfile integrity가 오래될 수 있다. 스냅샷을
다시 바꿀 때는 `npm run parser:sync`로 돌아가 package.json/lockfile과 vendor를 정렬한다.

현재 runtime export는 `parseSchedule`, `PARSER_INFO`, `INITIAL_POLICIES`다.
demo는 실제 함수와 공개 타입을 루트 패키지로부터 import하므로
타입 검사 및 Vite 빌드가 tarball의 공개 진입점과 타입 선언을 실제로 소비한다.

## Vercel 독립 설치

demo의 `vendor/*.tgz`, package.json, package-lock.json을 함께 관리한다.
`file:vendor/...tgz`는 레포 내부 상대 경로다. `file:../unplan-parser`, `npm link`,
`tsconfig.paths`/Vite alias로 형제 소스를 참조하는 구성은 배포에서 사용하지 않는다.

- Vercel Root Directory: demo 레포 루트.
- framework: Vite, install: `npm ci`, build: `npm run build`, output: `dist`.
- Node: Vercel이 제공하는 지원되는 22.x를 선택한다. 로컬 정확한 patch는 `.nvmrc` 기준.
- 서버 함수나 secret이 필요 없는 정적 앱이다. API routing/SPA rewrite는 현재 화면에 불필요하다.
- `vercel.json`을 제공했으나 실제 Vercel 배포나 플랫폼 실행은 검증하지 않는다.

## 향후 레지스트리 패키지로 전환

`@unplan-tave/parser`는 제안된 이름이다. npm scope 소유권, 공개 라이선스,
registry/access 및 최초 정식 버전을 먼저 확정한다. 이름은 GitHub 조직명만으로
npm 사용 권한이 보장되지 않는다. 정식 게시 이후 demo에서 승인된 정확한 버전을 설치한다.

예를 들어 **0.1.0이 실제 게시된 후에만**:

```sh
npm install --save-exact @unplan-tave/parser@0.1.0
npm ci
npm run check
```

범위(`^`, `~`) 대신 정확한 버전을 고정하고 demo lockfile을 함께 갱신한다. 기존 tarball은
참조가 사라진 뒤 삭제한다. npm 버전은 게시 뒤 덮어쓰지 않는다. 비공개 registry라면
Vercel secret의 registry 인증을 별도 구성하되 토큰을 레포에 넣지 않는다.
이 문서 작성 과정에서는 npm 게시·Vercel 배포를 실행하지 않는다.

## 브라우저 회귀 확인

데모에서 `npm run dev` 후 다른 터미널에서 `npm run test:browser`를 실행한다.
Playwright Chromium을 설치하거나 로컬 Chrome 경로를 `BROWSER_EXECUTABLE`로 전달한다.
독립 빌드는 parser 형제 폴더가 없는 임시 복사본에 demo 소스·vendor를 복사하고
`npm ci && npm run build`로 확인한다. 최신 실행 증거는 각 레포의 `MVP-VERIFICATION.md`다.
