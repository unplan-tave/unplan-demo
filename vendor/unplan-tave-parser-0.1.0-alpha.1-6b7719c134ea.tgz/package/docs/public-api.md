# 공개 API (MVP)

API 버전 `0.1.0-mvp.1`, 정책 버전 `ko-schedule-v0-mvp.1`.
이 문서는 구현된 MVP의 계약이다. 공개 타입은 `src/types.ts`, 단일 진입점은 `src/index.ts`다.

## 현재 사용 가능한 진입점

```ts
import {
  parseSchedule,
  PARSER_INFO,
  INITIAL_POLICIES,
} from '@unplan-tave/parser';
import type {
  ParseInput,
  ParseResult,
  InvalidContextResult,
  ScheduleParser,
} from '@unplan-tave/parser';
```

ESM 루트 하나를 제공한다. `dist/index.js`, `dist/index.d.ts`를 각각 JavaScript·타입
진입점으로 사용한다. 내부 파일 deep import와 CommonJS `require`는 지원 대상으로
선언하지 않는다. Vite 소비는 검증하지만 Expo SDK 56/Hermes 소비는 후속 검증이다.

`PARSER_INFO.implementation`은 `available`이다. `parseSchedule`은 `ScheduleParser` 타입을
만족하는 실제 동기 함수다. `INITIAL_POLICIES`는 구현에 적용한 MVP 기본 정책이다.

## 호출 계약

```ts
type ScheduleParser = (input: ParseInput) => ParseResult | InvalidContextResult;

// parseSchedule(input)으로 전체 문자열을 매번 분석한다.
const input: ParseInput = {
  text: '다음 주 월요일에 오후 3시 회의',
  referenceInstant: '2026-11-14T01:00:00Z',
  timeZone: 'Asia/Seoul',
};
```

- `text`: 수정·정규화 전 원문. 빈 문자열도 정상 입력이다.
- `referenceInstant`: `Z` 또는 명시적 offset을 포함한 ISO 8601 시각. 예:
  `2026-11-14T10:00:00+09:00`. offset 없는 문자열은 거부한다.
- `timeZone`: IANA 시간대 ID. 기준 시각을 이 시간대의 달력 날짜로 변환한다.
  시스템 시각·시간대 기본값, timezone 없는 Date 파싱을 사용하지 않는다.
- 정책 override는 MVP 입력에 포함하지 않는다. `INITIAL_POLICIES`를 따르며,
  향후 옵션 도입 시 문서와 타입을 같이 변경한다.
- 유효한 context는 `status: 'parsed'`로 반환한다. 자연어가 없거나 모호·미완성·잘못된
  경우에도 정상 분석 결과이며, 필드의 상태와 diagnostics로 설명한다.
- 잘못된 기준 시각 또는 지원하지 않는 시간대는 `status: 'invalid-context'`와
  `errors`를 반환한다. 이 경우 계산된 필드를 만들지 않는다. 잘못된 사용자 입력으로
  예외를 던지는 대신 이 union을 사용한다. 현재 실행 환경의 Intl IANA 지원을 검사하며, 실패하면 오류 union을 반환한다.

## 필드별 상태

날짜 `Field<DateValue>`, 시간 `Field<TimeValue>`, 제목 `Field<string>`을 독립적으로 반환한다.

| state        | 의미                                               | 필수 정보                                      |
| ------------ | -------------------------------------------------- | ---------------------------------------------- |
| `none`       | 해당 정보 없음                                     | 값/후보 없음                                   |
| `incomplete` | 시작했으나 완성되지 않은 표현                      | `sources`, `expected`(기대하는 다음 토큰 설명) |
| `resolved`   | 하나의 값으로 해석됨                               | `candidate`                                    |
| `ambiguous`  | 사용자의 선택이나 추가 입력이 필요함               | 최소 두 `candidates`, `sources`, `reason`      |
| `invalid`    | 지원 문법과 일치하지만 값이 유효하지 않거나 충돌함 | `sources`, `code`, `message`                   |

`다음 주 월요일에 오후`는 날짜 `resolved`, 시간 `incomplete`, 제목 `none`이다.
하나의 전역 `incomplete`로 나머지 날짜를 없애지 않는다. 제목은 초기 정책에서 주로
`none` 또는 `resolved`를 사용한다. 날짜 범위도 값 자체는 `resolved`일 수 있으므로,
소비자는 `state`뿐 아니라 `value.kind`를 확인해야 한다.

## 값·위치·근거

`DateValue`:

- `{ kind: 'date', date: '2026-11-16' }`: 해당 시간대의 달력 날짜.
- `{ kind: 'range', startDate: '2026-11-16', endDateExclusive: '2026-11-23', granularity: 'week' }`:
  달력의 주간 범위. 종료 날짜는 제외한다. 일정 시작·종료 시간이 아니다.

날짜만으로 ISO timestamp, `00:00`, `allDay: true`를 만들지 않는다. 계약에 일정 저장용
timestamp나 allDay 필드를 넣지 않는다. 날짜와 시간이 둘 다 있어도 instant로 조합하는
책임은 이후 일정 도메인 계층에 있다. DST gap/fold, 저장·종일 여부도 그 계층에서 결정한다.

`TimeValue`: `hour` 0–23, `minute` 0–59, `precision: 'hour' | 'minute'`.
`오후 3시`는 시 정밀도이며 생략된 분 0은 추론으로 기록한다. `반`, `분`, `HH:mm`은 분
정밀도다. 시간만 있다고 날짜를 오늘로 채우거나 과거 시간을 내일로 넘기지 않는다.

`Candidate<T>`는 `value`, `sources`, `derivations`를 갖는다. `SourceSpan`은
`{ start, end, text }`이며 **UTF-16 code unit, 0부터, end 제외**다. 항상
`input.text.slice(start, end) === text`. 한글 정규화·공백 제거·조사 처리는 offset을
변경하지 않는 매칭으로 수행한다. 이모지 뒤 위치도 JavaScript 문자열 인덱스를 따른다.
후보가 여러 island에서 조합되면 서로 떨어진 범위를 `sources`로 보존한다.

`Derivation.path`는 후보 값 기준 JSON pointer다. 문자열 자체의 경로는 빈 문자열 `''`.

- `kind: 'explicit'`: 사용자 원문에서 직접 온 값과 `sources`.
- `kind: 'inferred'`: `policy`, `sources`를 포함해 규칙으로 결정한 값.
- `오후 3시`: `/hour`는 `meridiem-to-24-hour`, `/minute`은
  `default-minute-zero` 추론. 원문에 명시된 숫자·오후는 source로 보존한다.
- `내일`: `/date`는 `relative-date` 추론. 표현은 명시되었어도 절대 날짜는 기준 시각과
  정책으로 계산된 값이므로 explicit이라고 표시하지 않는다.
- `15:30`: `/hour`, `/minute` 모두 explicit. 시/분 범위를 개별로 지정할 수 있다.
- 제목의 순수 잔여 텍스트는 explicit, 공백 결합을 거치면 `title-whitespace` 추론.

`LocalDate`, `ReferenceInstant`, IANA ID는 현재 단순 string alias다. TS 타입만으로 형식이나
값 범위를 보장한다고 주장하지 않는다. 엔진이 ISO 날짜·시각의 범위와 offset 및 Intl 시간대 가용성을 검증한다.

`expressions`는 날짜/시간의 complete·incomplete·ambiguous·invalid island와 원문 범위를
반환한다. `diagnostics`는 원문 위치와 안정적인 code를 담는다. UI는 번역 가능한 code를
사용하고 message 문구에 의존한 조건 분기를 하지 않는다. 지원하지 않는 반복·기간처럼
위험한 조합은 `unsupported-expression` warning을 통해 알린다.

## 제품 액션과 분리

아래는 소비자 제안 정책이며 파서가 버튼·저장·hook을 구현하는 것이 아니다.

| 조건                                                                       | 소비자 액션 초안                                                 |
| -------------------------------------------------------------------------- | ---------------------------------------------------------------- |
| 날짜 `resolved` + `kind: 'date'`, 시간 none/incomplete, 제목 none/resolved | 날짜 기준 초안 추가 가능. 미완성 시간은 계속 입력할 수 있게 표시 |
| 날짜가 단일 확정이고 시간 resolved                                         | 날짜·시간 초안 추가 가능                                         |
| 날짜 none/incomplete/ambiguous/invalid 또는 range                          | 특정 날짜를 임의로 골라 추가하지 않음                            |
| 시간 ambiguous/invalid                                                     | 날짜를 유지하며 시간 확인 요청, 원클릭 추가 보류                 |
| `unsupported-expression` warning                                           | 초기에는 원클릭 추가를 보류하고 지원 범위를 안내                 |

시간이 incomplete인 상태에서 버튼을 눌렀다면 그 부분을 제목이나 0시로 바꾸지 않고,
미완성 표현을 보여 주는 편집 초안으로 이어진다. 빈 제목은 초안에서 입력한다.
입력 변경은 분석만 하며 일정 저장을 유발하지 않는다. 데모는 이 정책으로 버튼 상태를 정하고, 클릭 시 편집 가능한 초안을 연다.
초안의 날짜·시간·제목은 편집할 수 있고 실제 저장은 수행하지 않는다.

## 변경 원칙

계약·정책의 의미가 바뀌면 타입, 두 버전 상수, 정책/예시 문서, 소비자 tarball을 함께
갱신한다. alpha 버전이라도 소비자 호환성을 검토하며, 정식 게시 시 immutable 버전을 쓴다.

## 초안에서 MVP로 전환한 기록

공개 Field/값/결과 union의 의미는 유지했다. 실제 함수 export를 추가하고 API 버전을
`0.1.0-draft.1`에서 `0.1.0-mvp.1`로 올렸다. 정책 버전은 가정을 기본값으로 채택한
`ko-schedule-v0-mvp.1`이다. 구현 불가능한 계약 모순은 없었다.

같은 시·분의 반복은 정밀도가 달라도 한 값으로 병합하며, 분 정밀도를 보존한다.
명확한 범위 오류는 같은 표현이 아직 입력 중이어도 invalid가 우선한다.
지원하지 않는 초 표기(`23:30:45`)를 작은 시간으로 자르지 않는다.
기준 ISO 문자열은 4자리 양의 연도, T, 시·분, 선택적 초·소수초, Z 또는 ±HH:mm을 받으며
24시·존재하지 않는 날짜·offset 없는 시각을 거부한다. named zone/alias는 호스트 Intl이
지원해야 하며 숫자 offset을 IANA ID 대신 주는 것은 거부한다.
