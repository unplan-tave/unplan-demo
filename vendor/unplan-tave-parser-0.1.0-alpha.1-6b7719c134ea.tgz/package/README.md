# Unplan Parser

한국어 일정 입력에서 날짜·시간·제목 후보를 찾는 순수 TypeScript 패키지다.
React 웹과 향후 Expo SDK 56 앱이 같은 코어를 소비하는 것을 목표로 한다.

**현재: 한국어 일정 파서 MVP (`0.1.0-alpha.1`).** `parseSchedule`을 동기 호출해 날짜·시간·제목,
필드별 상태, UTF-16 원문 위치, diagnostics, 추론 근거를 얻는다. 런타임 의존성은 없다.
Node 22.20.0과 Chromium/Vite 소비를 검증한다. Expo SDK 56/Hermes는 아직 검증하지 않았다.

## 시작하기

Node 22.20.0 (`.nvmrc`), npm 10.9.3을 기준으로 세팅했다.

```sh
nvm use
npm ci
npm test
npm run typecheck
npm run lint
npm run format:check
npm run build
# 전체 검증: npm run check
```

`dist/`에 ESM JavaScript와 `.d.ts`를 만든다. 소스의 내부 import는 `.js` 확장자를 쓴다.
코어는 DOM/Node ambient 타입, UI, 네트워크, 저장소에 의존하지 않는다.

```ts
import { parseSchedule } from '@unplan-tave/parser';

const result = parseSchedule({
  text: '다음 주 월요일에 오후 3시 회의',
  referenceInstant: '2026-11-14T01:00:00Z',
  timeZone: 'Asia/Seoul',
});
// status === 'parsed': date 2026-11-16, time 15:00, title 회의
// 잘못된 context는 status === 'invalid-context'로 반환한다.
```

## 데모와 연결

독립 레포인 [unplan-demo](https://github.com/unplan-tave/unplan-demo)가 같은 상위 폴더에
있다면, parser에서 `npm ci`를 끝낸 뒤 다음을 실행한다.

```sh
cd ../unplan-demo
npm ci
npm run parser:sync
npm run check
npm run dev
```

동기화 스크립트는 parser의 `npm pack`을 통해 빌드하고, demo의 `vendor/`에 tarball을
복사해 공개 패키지로 설치한다. demo의 기존 스냅샷만 실행할 때는 parser 폴더가 필요 없다.
수동 `npm pack` 검증, 다른 경로, Vercel/정식 패키지 전환은
[개발·패키지 연결](docs/development.md)에 설명한다.

## 설계 기준 문서

- [공개 API와 상태 모델](docs/public-api.md)
- [지원 표현과 해석 정책](docs/interpretation-policy.md)
- [대표 입력·기대 결과와 실행 fixture](docs/examples.md)
- [구조·도구 선택과 후속 작업](docs/architecture.md)
- [설치·패키지 검증·배포 전환](docs/development.md)

지원: 오늘·내일·모레, 이번/다음 주와 요일, 단독 요일, 오전·오후+시/분/반,
H:mm/HH:mm, 오전·오후 없는 시의 모호함, 문서의 띄어쓰기·조사·경계.
날짜·시간은 독립적이며 날짜만으로 자정·종일, 시간만으로 오늘을 채우지 않는다.
반복·기간 표식은 unsupported 경고다. 숫자 연월일, 한글 수사, 다중 일정, 대화 의도 해석,
저장 instant/DST gap·fold 처리는 미지원이다. `npm test`는 문서 예시 39개와 경계 동작을 검증한다.
다음 작업은 Expo SDK 56/Hermes 검증과 실제 한국어 데이터 기반 경계 개선이다.
패키지 이름 `@unplan-tave/parser`와 라이선스는 임시 결정이다. npm scope 소유권과 공개
라이선스 승인 전에는 게시하지 않는다. 이번 MVP 작업에서는 게시·배포·커밋·푸시·PR을 하지 않는다.
